#include "veh_basic.h"

c_current_veh::c_current_veh()
{
}


