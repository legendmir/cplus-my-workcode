#include"path.h"

std::string c_path::source_path = "F:\\Job Project\\Peugeot\\AWRoot\\dtrd\\tree\\";
std::string c_path::output_path = "C:\\Users\\Administrator\\Desktop\\PSA_data\\";
std::string c_path::func_path = "C:\\Users\\Administrator\\Desktop\\PSA_data\\func_file\\";
std::string c_path::db_path="F:\\Job Project\\Peugeot\\\db_path\\";