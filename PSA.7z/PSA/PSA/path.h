#pragma once
#include<string>

class c_path
{
public:
	static std::string source_path;
	static std::string output_path;
	static std::string func_path;
	static std::string db_path;
};
